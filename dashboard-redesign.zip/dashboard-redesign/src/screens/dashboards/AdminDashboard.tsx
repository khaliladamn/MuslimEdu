import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../../context/AuthContext';
import DashboardShell, { EMERALD, EMERALD_SOFT, INK, SUBTLE } from './DashboardShell';

// Alternating solid/soft emerald tiles for visual rhythm, all one color family.
const MENU_ITEMS = [
  { key: 'students', route: 'StudentsList', params: {}, style: 'solid' as const },
  { key: 'teachers', label: 'Teachers', route: null, style: 'soft' as const },
  { key: 'classes', label: 'Classes', route: null, style: 'soft' as const },
  { key: 'fees', label: 'Fee Reports', route: null, style: 'solid' as const },
  { key: 'attendance', label: 'Attendance', route: null, style: 'soft' as const },
];

export default function AdminDashboard() {
  const navigation = useNavigation();
  const { user } = useAuth();

  const studentsLabel = user?.is_orphan ? 'Children' : 'Students';

  return (
    <DashboardShell title="Admin">
      <Text style={styles.sectionLabel}>Manage</Text>

      <View style={styles.grid}>
        {MENU_ITEMS.map((item) => (
          <TouchableOpacity
            key={item.key}
            style={[styles.card, item.style === 'solid' ? styles.cardSolid : styles.cardSoft]}
            activeOpacity={0.8}
            onPress={() => {
              if (item.route) {
                (navigation as any).navigate(item.route, item.params);
              }
            }}
          >
            <Text style={[styles.cardText, item.style === 'solid' && styles.cardTextSolid]}>
              {item.key === 'students' ? studentsLabel : item.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.noteBox}>
        <Text style={styles.noteText}>
          {studentsLabel} is now wired to real data. The rest are
          placeholders - tell me which to build out next.
        </Text>
      </View>
    </DashboardShell>
  );
}

const styles = StyleSheet.create({
  sectionLabel: {
    fontSize: 13,
    color: SUBTLE,
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    fontWeight: '600',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: '48%',
    borderRadius: 18,
    paddingVertical: 26,
    paddingHorizontal: 14,
    alignItems: 'center',
    marginBottom: 12,
  },
  cardSolid: { backgroundColor: EMERALD },
  cardSoft: { backgroundColor: EMERALD_SOFT },
  cardText: { fontSize: 14, fontWeight: '700', color: EMERALD, textAlign: 'center' },
  cardTextSolid: { color: '#FFFFFF' },
  noteBox: {
    marginTop: 8,
    backgroundColor: EMERALD_SOFT,
    borderRadius: 14,
    padding: 16,
    borderLeftWidth: 3,
    borderLeftColor: EMERALD,
  },
  noteText: { fontSize: 13, color: INK, lineHeight: 19 },
});
