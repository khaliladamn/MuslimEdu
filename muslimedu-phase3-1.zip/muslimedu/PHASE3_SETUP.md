# Phase 3 Setup — MuslimEdu Login Screen

## 1. Install dependencies

```bash
npm install @react-navigation/native @react-navigation/native-stack
npm install react-native-screens react-native-safe-area-context
npm install react-native-keychain
```

Then for iOS only (skip if Android-only for now):
```bash
cd ios && pod install && cd ..
```

## 2. Add your app icon

Put your MuslimEdu app icon PNG at:
```
src/assets/images/app-icon.png
```
(create the `src/assets/images/` folders if they don't exist). If you'd rather skip this for now, just delete the `<Image .../>` block in `LoginScreen.tsx` temporarily — everything else will still work.

## 3. Add the Inter font (for the Apple-like look)

1. Download these three weights from https://fonts.google.com/specimen/Inter:
   - `Inter-Regular.ttf`
   - `Inter-SemiBold.ttf`
2. Place them in a new folder at the project root:
   ```
   assets/fonts/Inter-Regular.ttf
   assets/fonts/Inter-SemiBold.ttf
   ```
3. Create/edit `react-native.config.js` at the project root:
   ```js
   module.exports = {
     assets: ['./assets/fonts'],
   };
   ```
4. Link the fonts:
   ```bash
   npx react-native-asset
   ```
5. Rebuild the app (fonts require a native rebuild, not just a JS reload):
   ```bash
   npx react-native run-android
   ```

If you'd rather skip custom fonts for now and just test login functionality first, that's fine — remove the `fontFamily` lines from `LoginScreen.tsx` and it'll fall back to the system font (Roboto on Android), and we can add Inter back in later.

## 4. Drop in the files

Copy these into your project, preserving the folder structure:
- `src/config/api.ts`
- `src/services/authService.ts`
- `src/context/AuthContext.tsx`
- `src/screens/LoginScreen.tsx`
- `src/navigation/RootNavigator.tsx`
- `App.tsx` (overwrite your existing root App.tsx)

## 5. Run it

```bash
npx react-native run-android
```

Log in with the same test account we confirmed in Phase 2 (`haysam@icf.com`) and confirm:
- Login screen renders (white background, emerald button)
- Submitting valid credentials navigates to the placeholder Home screen showing name + role
- Wrong password shows the red error text
- Killing and reopening the app keeps you logged in (token persisted via Keychain)
- "Log out" button returns you to the login screen
