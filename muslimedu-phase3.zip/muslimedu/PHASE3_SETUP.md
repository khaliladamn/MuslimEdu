# MuslimEdu — Phase 3 Setup

Everything is already built and included in this zip: code files + your app icon.
No fonts to download, nothing else to gather. Just these 3 steps.

## Step 1 — Extract into your project

In the Codespace terminal:

```bash
cd /workspaces/MuslimEdu
unzip -o muslimedu-phase3.zip
cp -r muslimedu/* ./
rm -rf muslimedu muslimedu-phase3.zip
```

## Step 2 — Install packages

```bash
npm install @react-navigation/native @react-navigation/native-stack react-native-screens react-native-safe-area-context react-native-keychain
```

(iOS only — skip if you're testing on Android)
```bash
cd ios && pod install && cd ..
```

## Step 3 — Run it

```bash
npx react-native run-android
```

## What to check

- White login screen with the green icon at top and an emerald "Sign In" button
- Log in with a real account → goes to a placeholder screen showing your name + role
- Wrong password → shows a red error message
- Close and reopen the app → still logged in
- "Log out" button → back to login screen

If it doesn't build, copy the exact error text here and I'll fix it.
