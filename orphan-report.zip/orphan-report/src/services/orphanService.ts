import { API_BASE_URL } from '../config/api';

export interface ReportPhoto {
  url: string;
}

export interface MonthlyReport {
  id: number;
  report_month: string; // "2026-07-01"
  note: string | null;
  academic_rating: number | null;
  wellbeing_rating: number | null;
  submitted_by: string | null;
  photos: string[];
}

export interface ReportStatus {
  submitted_this_month: boolean;
  current_report: MonthlyReport | null;
  history: MonthlyReport[];
}

async function authedPost(path: string, token: string, body: FormData | Record<string, any>) {
  const isFormData = body instanceof FormData;

  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
      Authorization: `Bearer ${token}`,
    },
    body: isFormData ? body : JSON.stringify(body),
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data?.message ?? `Request failed (${response.status})`);
  }

  return data;
}

/** POST /orphan_report_status - current month status + full history */
export async function fetchReportStatus(token: string): Promise<ReportStatus> {
  return authedPost('/orphan_report_status', token, {});
}

/** POST /orphan_report_submit - submit this month's report */
export async function submitReport(
  token: string,
  fields: { note: string; academic_rating: number; wellbeing_rating: number },
): Promise<{ message: string; report: MonthlyReport }> {
  // Sent as JSON for now since photo picking isn't wired up yet (see note
  // in OrphanReportScreen.tsx). Once a photo library is added, switch this
  // to FormData and append photos the same way profile photo upload would.
  return authedPost('/orphan_report_submit', token, fields);
}
